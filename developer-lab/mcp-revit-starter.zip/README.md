# MCP Academy — Custom Revit MCP Starter

**Author: Ygor Fasanella · 2026**

## Status

Educational **source-code starter**, not an independently validated Revit add-in. Python source syntax was checked separately; actual Windows/Revit integration, C# compilation, HttpListener reservations, and SDK dependencies must be tested on a machine running the target Revit version. This is not Autodesk's official MCP server.

This project deliberately supports **read-only** operations only. The original RVT and IFC files are **not** included in this archive.

## Architecture

MCP Inspector or compatible client → Python MCPServer (STDIO) → localhost HTTP GET (127.0.0.1:8765) → C# Revit add-in → Revit `ExternalEvent` → live Revit API.

No arbitrary code execution, no model write tool, no external listener bind. Nevertheless, other local processes could access the unauthenticated localhost endpoint. Use on a trusted training machine; do not open the port to a network or use with sensitive projects without adding authentication.

## 1 · No-Revit static sample

Install Python (preferably 3.11+), uv, Node.js with npx. From `python/`:

```powershell
uv init --bare
uv add "mcp[cli]"
uv run mcp dev snapshot_server.py
```

Test `get_course_model_counts("IfcWall")` — expected `30`, with source `static IFC4X3_ADD2 export; not live Revit`. These counts are taken from the supplied reference IFC, **not** from an open Revit document.

## 2 · Revit 2027.3 add-in

1. Use Revit 2027.3 and a suitable .NET 10 SDK on Windows. Autodesk lists .NET 10 for Revit 2027 add-ins. This Academy targets Revit 2027.3, with MCP compatibility confirmed by the course author; validate this starter against your installed build.
2. Edit the `.csproj` HintPaths if the installed API DLLs are elsewhere.
3. From `RevitMcpLab.Addin/`, run `dotnet build -c Release`.
4. Edit `RevitMcpLab.addin`: set the absolute path to `RevitMcpLab.Addin.dll` (usually under `bin/Release/net10.0-windows/`).
5. Copy `RevitMcpLab.addin` to `%APPDATA%\Autodesk\Revit\Addins\2027\` and reopen Revit.
6. Ensure the add-in starts without errors. Windows HttpListener may require a URL ACL reservation or permission adjustment; resolve using Microsoft's documentation and do **not** expose the port beyond loopback.
7. Open the training RVT copy in Revit and test http://127.0.0.1:8765/document on the same machine.

## 3 · MCP bridge

In `python/` run:

```powershell
uv run mcp dev server.py
```

Tools:
- `get_model_info()` — get current document title through live Revit.
- `count_revit_elements("Walls" | "Doors" | "Windows")` — return counts from the current document.

If an error occurs, test the local endpoint independently; then inspect the MCP tool. Values can differ from IFC export counts due to document/export scope. This starter has never been used to modify Revit.

## Important technical limitations

- This code has not been compiled against the target Revit API in this environment. Treat it as a guided starter, not a verified executable deliverable.
- Revit API must run in the valid UI/API context; use `ExternalEvent`, not direct model calls from the HTTP server thread.
- Timeout responses can occur if Revit is busy or modal; always handle failures.
- The example supports only one local read-only request at a time in normal teaching use; production deployment requires access control, request correlation, cancellation handling, load testing, logging and hardened error handling.
- Do not publish proprietary or personal data obtained from model queries.

## Primary sources

- [MCP Python SDK v2](https://py.sdk.modelcontextprotocol.io/)
- [Autodesk External Events](https://help.autodesk.com/cloudhelp/2026/ENU/Revit-API/files/Revit_API_Developers_Guide/Advanced_Topics/Revit_API_Revit_API_Developers_Guide_Advanced_Topics_External_Events_html.html)
- [Autodesk Revit 2027 .NET 10](https://help.autodesk.com/cloudhelp/2027/ITA/Revit-WhatsNew/files/GUID-8D7A4715-EAF8-4BD1-BE78-061F900D0BCE.htm)
