using System;
using System.Collections.Concurrent;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace RevitMcpLab.Addin;

public sealed class LabApplication : IExternalApplication
{
    private HttpListener? _listener;
    private CancellationTokenSource? _cancel;
    private Task? _loop;
    private ExternalEvent? _event;
    private readonly LabEventHandler _handler = new();

    public Result OnStartup(UIControlledApplication application)
    {
        try
        {
            _event = ExternalEvent.Create(_handler);
            _listener = new HttpListener();
            // Read-only educational bridge. Accessible on localhost only.
            _listener.Prefixes.Add("http://127.0.0.1:8765/");
            _listener.Start();
            _cancel = new CancellationTokenSource();
            _loop = Task.Run(() => ServeAsync(_cancel.Token));
            return Result.Succeeded;
        }
        catch (Exception ex)
        {
            TaskDialog.Show("MCP Academy Developer Lab", "Bridge startup failed: " + ex.Message);
            return Result.Failed;
        }
    }

    private async Task ServeAsync(CancellationToken token)
    {
        if (_listener is null) return;
        while (!token.IsCancellationRequested)
        {
            HttpListenerContext ctx;
            try { ctx = await _listener.GetContextAsync(); }
            catch (HttpListenerException) { break; }
            catch (ObjectDisposedException) { break; }
            try
            {
                if (ctx.Request.HttpMethod != "GET")
                {
                    ctx.Response.StatusCode = 405;
                    await SendJson(ctx, new { error = "method_not_allowed" });
                    continue;
                }
                var path = ctx.Request.Url?.AbsolutePath.Trim('/');
                if (path != "document" && path != "count")
                {
                    ctx.Response.StatusCode = 404;
                    await SendJson(ctx, new { error = "unknown_endpoint" });
                    continue;
                }
                var category = ctx.Request.QueryString["category"];
                var pending = new Pending(path, category);
                _handler.Enqueue(pending);
                if (_event?.Raise() != ExternalEventRequest.Accepted)
                {
                    _handler.Cancel(pending);
                    ctx.Response.StatusCode = 503;
                    await SendJson(ctx, new { error = "external_event_busy" });
                    continue;
                }
                string json = await pending.Result.Task.WaitAsync(TimeSpan.FromSeconds(15), token);
                await SendRawJson(ctx, json);
            }
            catch (TimeoutException)
            {
                ctx.Response.StatusCode = 504;
                await SendJson(ctx, new { error = "revit_timeout" });
            }
            catch (Exception ex)
            {
                ctx.Response.StatusCode = 500;
                await SendJson(ctx, new { error = ex.GetType().Name });
            }
        }
    }

    private static Task SendJson(HttpListenerContext ctx, object obj) =>
        SendRawJson(ctx, JsonSerializer.Serialize(obj));

    private static async Task SendRawJson(HttpListenerContext ctx, string json)
    {
        var bytes = Encoding.UTF8.GetBytes(json);
        ctx.Response.ContentType = "application/json";
        ctx.Response.ContentEncoding = Encoding.UTF8;
        ctx.Response.ContentLength64 = bytes.Length;
        await ctx.Response.OutputStream.WriteAsync(bytes);
        ctx.Response.Close();
    }

    public Result OnShutdown(UIControlledApplication application)
    {
        _cancel?.Cancel();
        _listener?.Stop();
        _listener?.Close();
        _event?.Dispose();
        _cancel?.Dispose();
        return Result.Succeeded;
    }
}

internal sealed class Pending(string endpoint, string? category)
{
    public string Endpoint { get; } = endpoint;
    public string? Category { get; } = category;
    public TaskCompletionSource<string> Result { get; } =
        new(TaskCreationOptions.RunContinuationsAsynchronously);
}

internal sealed class LabEventHandler : IExternalEventHandler
{
    private readonly ConcurrentQueue<Pending> _queue = new();
    public void Enqueue(Pending request) => _queue.Enqueue(request);
    public void Cancel(Pending request) => request.Result.TrySetCanceled();
    public string GetName() => "MCP Academy read-only Revit request";

    public void Execute(UIApplication app)
    {
        while (_queue.TryDequeue(out Pending? r))
        {
            if (r.Result.Task.IsCompleted) continue;
            try
            {
                var doc = app.ActiveUIDocument?.Document;
                if (doc is null)
                {
                    r.Result.TrySetResult(JsonSerializer.Serialize(new { error = "no_document" }));
                    continue;
                }
                if (r.Endpoint == "document")
                {
                    r.Result.TrySetResult(JsonSerializer.Serialize(new
                    {
                        document = doc.Title, source = "live Revit API", readOnly = true
                    }));
                    continue;
                }
                BuiltInCategory bic = r.Category switch
                {
                    "Walls" => BuiltInCategory.OST_Walls,
                    "Doors" => BuiltInCategory.OST_Doors,
                    "Windows" => BuiltInCategory.OST_Windows,
                    _ => (BuiltInCategory)(-1)
                };
                if ((int)bic == -1)
                {
                    r.Result.TrySetResult(JsonSerializer.Serialize(new
                    { error = "unsupported_category", category = r.Category }));
                    continue;
                }
                int n = new FilteredElementCollector(doc)
                    .OfCategory(bic)
                    .WhereElementIsNotElementType()
                    .GetElementCount();
                r.Result.TrySetResult(JsonSerializer.Serialize(new
                {
                    category = r.Category, count = n,
                    source = "live Revit API", document = doc.Title
                }));
            }
            catch (Exception ex)
            {
                r.Result.TrySetResult(JsonSerializer.Serialize(new { error = ex.Message }));
            }
        }
    }
}
