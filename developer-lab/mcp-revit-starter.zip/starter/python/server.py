"""Read-only MCP bridge for the MCP Academy Revit 2027 Developer Lab.

This example is a starter to be tested on Windows with Revit 2027 and the
corresponding Revit API. It does NOT access the course IFC directly.
"""
from __future__ import annotations

import json
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import urlopen

from mcp.server import MCPServer

mcp = MCPServer("MCP Academy custom Revit bridge")
BASE_URL = "http://127.0.0.1:8765"


def _query(endpoint: str, params: dict[str, str] | None = None) -> dict:
    """Make a localhost-only read request; never expose arbitrary routes."""
    if endpoint not in {"document", "count"}:
        raise ValueError("Unsupported endpoint")
    url = f"{BASE_URL}/{endpoint}"
    if params:
        url += "?" + urlencode(params)
    try:
        with urlopen(url, timeout=20) as result:
            return json.loads(result.read().decode("utf-8"))
    except (URLError, HTTPError, json.JSONDecodeError) as exc:
        return {"error": str(exc), "source": "local_revit_bridge"}


@mcp.tool()
def get_model_info() -> dict:
    """Return basic information about the active Revit document, read-only."""
    return _query("document")


@mcp.tool()
def count_revit_elements(category: str) -> dict:
    """Count instances in one of Walls, Doors, Windows in the open Revit model."""
    allowed = {"Walls", "Doors", "Windows"}
    if category not in allowed:
        return {"error": "unsupported_category", "allowed_categories": sorted(allowed)}
    return _query("count", {"category": category})


if __name__ == "__main__":
    mcp.run(transport="stdio")
