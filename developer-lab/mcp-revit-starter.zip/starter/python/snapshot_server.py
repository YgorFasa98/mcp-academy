"""No-Revit, no-LLM testing sample based on the supplied IFC export."""
from mcp.server import MCPServer

mcp = MCPServer("MCP Academy static IFC exercise")
COUNTS = {
    "IfcWall": 30, "IfcDoor": 15, "IfcWindow": 7,
    "IfcSlab": 11, "IfcColumn": 21, "IfcBeam": 14,
    "IfcSpace": 13, "IfcBuildingStorey": 6,
}


@mcp.tool()
def get_course_model_counts(category: str) -> dict:
    """Return an observed IFC entity count from the static course snapshot."""
    if category not in COUNTS:
        return {"error": "unsupported_category", "categories": sorted(COUNTS)}
    return {"category": category, "count": COUNTS[category],
            "source": "static IFC4X3_ADD2 export; not live Revit"}


@mcp.tool()
def get_course_model_info() -> dict:
    """Return static training IFC metadata (excluding personal information)."""
    return {"schema": "IFC4X3_ADD2", "building_storeys": 6,
            "source": "static course snapshot; not live Revit"}


if __name__ == "__main__":
    mcp.run(transport="stdio")
